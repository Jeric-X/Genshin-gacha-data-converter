# To Test

- The following tests should be performed. 
	- Microsoft Excel, Google Spreadsheet, LibreOffice Calc Spreasheet

- Unicode test (filename :cloud:, filepath :cloud:, data value :sunny:)
